function iD(el) {
    return document.getElementById(el)
}