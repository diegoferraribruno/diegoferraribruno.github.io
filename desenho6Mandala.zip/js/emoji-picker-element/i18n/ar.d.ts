import { I18n } from "../shared";
declare const _default: I18n;
export default _default;